package com.kafka.DKafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DKafkaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DKafkaApplication.class, args);
	}

}
