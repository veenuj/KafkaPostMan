package com.kafka.DKafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DKafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
